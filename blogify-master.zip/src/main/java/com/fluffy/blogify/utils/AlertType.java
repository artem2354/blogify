package com.fluffy.blogify.utils;

public enum AlertType {
    ERROR,
    WARNING,
    INFO,
    SUCCESS;
}
